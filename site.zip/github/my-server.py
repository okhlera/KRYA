from flask import Flask, render_template
import random
weatherArr=["Ветер","Облачно","Солнечно"]
imageArr=["sun.png","clouds.png","wind.png"]
# pip3 install flask

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/weather')
def projects():
    weather = random.choice(weatherArr)
    if weather[0] == "В":
        image = "/static/image/" + imageArr[2]
    if weather[0] == "О":
        image = "/static/image/" + imageArr[1]
    if weather[0] == "С":
        image = "/static/image/" + imageArr[0]
    return render_template('weather.html',weather=weather,image=image)
@app.route('/me')
def hobbies():
    return render_template('hobbies.html')
# запускаем сайт
app.run(debug=True, port=8080)