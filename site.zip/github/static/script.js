let weatherArr=["sun","snow","wind","clouds"];
function GetRandomWeather(){
    weather = weatherArr[Math.floor(Math.random()*weatherArr.length)];
    if weather[1]=="u"{
        return  "Солнечно"
    }
    if weather[1]=="n"{
        return  "Снегопад"
    }
    if weather[1]=="i"{
        return  "Ветренно"
    }
    if weather[1]=="l"{
        return  "Облачно"
    }
};